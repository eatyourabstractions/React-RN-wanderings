import React from 'react';

import GridContainer from './components/GridContainer'

function App() {
  return (
    <div className="App">
      <body>
        <GridContainer/>
      </body>
    </div>
  );
}

export default App;
