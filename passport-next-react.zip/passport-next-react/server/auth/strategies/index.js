import { strategy as JWTStrategy } from './jwt'

export { JWTStrategy }