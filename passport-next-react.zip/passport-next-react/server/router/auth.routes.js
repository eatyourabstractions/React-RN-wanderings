import express from 'express'
import { to } from 'await-to-js'
import { verifyPassword, hashPassword } from '../auth/utils'
import { login } from '../auth/strategies/jwt'
import { createUser, getUserByEmail } from '../database/user'

function isValidEmail(email) {
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}


const router = express.Router()

router.post('/login', async (req, res) => {
  const { email, password } = req.body
  const [err, user] = await to(getUserByEmail(email))

  const authenticationError = () => {
        return res
          .status(500)
          .json({ success: false, data: "Authentication error!" })
    }
    if (!(await verifyPassword(password, user.password))) {
         console.error('Passwords do not match')
        return authenticationError()
      }


  const [loginErr, token] = await to(login(req, user))


    if (loginErr) {
      console.error('Log in error', loginErr)
        return authenticationError()
    }

      return res
          .status(200)
          .cookie('jwt', token, {
            httpOnly: true
          })
            .json({
              success: true,
              data: '/'
            })
})

router.post('/register', async (req, res) => {
  const { firstName, lastName, email, password } = req.body
    if (!isValidEmail(email)) {
          return res.status(500).json({ success: false, data: 'Enter a valid email address.' })
      } else if (password.length < 5 || password.length > 20) {
          return res.status(500).json({
            success: false,
           data: 'Password must be between 5 and 20 characters.'
        })
      }

        let [err, user] = await to(
            createUser({
              firstName,
              lastName,
              email,
              password: await hashPassword(password)
            })
          )

        if (err) {
              return res.status(500).json({ success: false, data: 'Email is already taken' })
            }

        const [loginErr, token] = await to(login(req, user))
            
          if (loginErr) {
            console.error(loginErr)
            return res.status(500).json({ success: false, data: 'Authentication error!' })
            }

          return res
                .status(200)
                .cookie('jwt', token, {
                  httpOnly: true
                })
                .json({
                  success: true,
                  data: '/'
                })
            

})

export default router